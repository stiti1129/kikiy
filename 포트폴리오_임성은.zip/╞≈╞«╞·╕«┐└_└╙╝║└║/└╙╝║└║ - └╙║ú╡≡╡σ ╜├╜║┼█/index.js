var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express', number: "", number_2: "", number_3:"",number_4:""});
});

module.exports = router;
