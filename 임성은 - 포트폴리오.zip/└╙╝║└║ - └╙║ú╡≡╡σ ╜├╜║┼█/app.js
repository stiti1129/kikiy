var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var http = require('http');
var engine = require('ejs-locals');

var routes = require('./routes/index');
var users = require('./routes/users');
var speed = 1;

var value = 1;
var value_2 = 1;
var value_3 = 1;
var value_4 = 1;
var app = express();
var status_1 = 0;
var status_2 = 0;
var status_3 = 0;
var status_4 = 0;


// view engine setup
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);

app.engine('ejs', engine);

app.post('/', function(req, res) {
  res.render('index', {title: 'Start page', number: value, number_2: value_2, number_3: value_3, number_4: value_4});
  console.log(status_1);
  console.log(status_2);
});

app.post('/pot/on', function(req, res) {
  status_1 = 1;
  res.render('index', {title: 'Express', number:value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/pot/off', function(req, res) {
  status_1 = 0;
  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/pot/auto', function(req, res) {
  status_1 = 2;
  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});

app.post('/gas/on', function(req, res) {
  status_2 = 1;
  res.render('index', {title: 'Express', number:value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/gas/off', function(req, res) {
  status_2 = 0;
  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/gas/auto', function(req, res) {
  status_2 = 2;
  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});

app.post('/air/on', function(req, res) {
	  status_3 = 1;
	  res.render('index', {title: 'Express', number:value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/air/off', function(req, res) {
	  status_3 = 0;
	  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/air/auto', function(req, res) {
	  status_3 = 2;
	  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});

app.post('/io/on', function(req, res) {
  status_4 = 1;
  res.render('index', {title: 'Express', number:value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/io/off', function(req, res) {
  status_4 = 0;
  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});
app.post('/io/auto', function(req, res) {
  status_4 = 2;
  res.render('index', { title: 'Express', number: value, number_2: value_2, number_3: value_3, number_4: value_4 });
});




// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  console.log("Number 1 !!");
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') == 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}


// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});



var server = http.createServer(app).listen(app.get('port'), '175.192.216.166', function(){
  console.log('Express server listening on port ' + app.get('port'));
});

//
// Serial Port를 사용하는 예제
//

var SerialPort = require("serialport").SerialPort;

// Arduino가 /dev/tty-usbserial1 에 연결되었다고 가정합니다.
/*
var serialPort = new SerialPort('COM6', {
    baudrate: 9600
}, false);
var serialPort_2 = new SerialPort('COM4', {
    baudrate: 9600
}, false);
*/
var serialPort_3 = new SerialPort('COM4', {
    baudrate: 9600
}, false);
var serialPort_4 = new SerialPort('COM6', {
    baudrate: 9600
}, false);



/*
setInterval(function(){
   if(status_1==0) serialPort.write("0",function(err,results) {});
   else if(status_1==1) serialPort.write("1",function(err,results) {});
   else serialPort.write("2",function(err,results) {});

   if (status_2==0) serialPort_2.write("0", function(err, results){});
   else if (status_2==1) serialPort_2.write("1", function(err, results){});
   else serialPort_2.write("2", function(err, results){});
}, 1);
*/
    setInterval(function(){
    	   if(status_3==0) serialPort_3.write("0",function(err,results) {});
    	   else if(status_3==1) serialPort_3.write("1",function(err,results) {});
    	   else serialPort_3.write("2",function(err,results) {});

    	   if (status_4==0) serialPort_4.write("0", function(err, results){});
    	   else if (status_4==1) serialPort_4.write("1", function(err, results){});
    	   else serialPort_4.write("2", function(err, results){});
    	}, 1);
/*
serialPort.open(function () {
    console.log('open 접속되었구요');
    serialPort.on('data', function(data) {
        // Arduino 쪽에서 뭔가 출력했다면 여길 통해서 데이터를 볼 수 있습니다.
    if (data>200 && data<1000)
       value = data;
    });
});
serialPort_2.open(function () {
    console.log('open 2 접속되었구요');
    serialPort_2.on('data', function(data2) {
        // Arduino 쪽에서 뭔가 출력했다면 여길 통해서 데이터를 볼 수 있습니다.
    if (data2>120 && data2<1190)
       value_2 = data2;
    });
}); 
*/
serialPort_3.open(function () {
    console.log('open3 접속되었구요');
    serialPort_3.on('data', function(data3) {
        // Arduino 쪽에서 뭔가 출력했다면 여길 통해서 데이터를 볼 수 있습니다.
    if (data3>10 && data3<90)
       value_3 = data3;
    
    });
});
serialPort_4.open(function () {
    console.log('open4 접속되었구요');
    serialPort_4.on('data', function(data4) {
        // Arduino 쪽에서 뭔가 출력했다면 여길 통해서 데이터를 볼 수 있습니다.
       if(data4 == 11) value_4 = 'safe';
       else if(data4 == 22) value_4 = 'off';
       else if(data4==33) value_4 = 'invaded';
       
    });
}); 




module.exports = app;